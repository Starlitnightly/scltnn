scltnn.utils.cal\_model\_time
=============================

.. currentmodule:: scltnn.utils

.. autofunction:: cal_model_time