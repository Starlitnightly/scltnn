scltnn.models.scLTNN.cal\_distrubute
====================================

.. currentmodule:: scltnn.models

.. automethod:: scLTNN.cal_distrubute