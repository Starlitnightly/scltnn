scltnn.datasets.Pancreas
========================

.. currentmodule:: scltnn.datasets

.. autofunction:: Pancreas