scltnn.plot.get\_publication\_colors
====================================

.. currentmodule:: scltnn.plot

.. autofunction:: get_publication_colors