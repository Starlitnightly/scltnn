scltnn.plot.set\_publication\_params
====================================

.. currentmodule:: scltnn.plot

.. autofunction:: set_publication_params