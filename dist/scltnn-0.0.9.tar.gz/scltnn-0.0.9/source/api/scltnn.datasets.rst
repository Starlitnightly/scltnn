scltnn.datasets
===============

.. automodule:: scltnn.datasets

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
      :nosignatures:
   
      Cancer_CD8
      Pancreas
      Zebrafish
      data_downloader
   
   

   
   
   

   
   
   



