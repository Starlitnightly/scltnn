scltnn.datasets.data\_downloader
================================

.. currentmodule:: scltnn.datasets

.. autofunction:: data_downloader