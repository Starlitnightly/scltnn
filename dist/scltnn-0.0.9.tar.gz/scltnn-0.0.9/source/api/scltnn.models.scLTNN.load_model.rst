scltnn.models.scLTNN.load\_model
================================

.. currentmodule:: scltnn.models

.. automethod:: scLTNN.load_model