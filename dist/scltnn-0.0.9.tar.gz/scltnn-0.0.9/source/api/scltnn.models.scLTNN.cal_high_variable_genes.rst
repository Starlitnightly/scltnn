scltnn.models.scLTNN.cal\_high\_variable\_genes
===============================================

.. currentmodule:: scltnn.models

.. automethod:: scLTNN.cal_high_variable_genes