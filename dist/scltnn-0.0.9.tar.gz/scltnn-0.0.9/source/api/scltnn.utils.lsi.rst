scltnn.utils.lsi
================

.. currentmodule:: scltnn.utils

.. autofunction:: lsi