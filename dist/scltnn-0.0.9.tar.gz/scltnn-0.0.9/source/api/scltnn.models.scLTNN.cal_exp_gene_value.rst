scltnn.models.scLTNN.cal\_exp\_gene\_value
==========================================

.. currentmodule:: scltnn.models

.. automethod:: scLTNN.cal_exp_gene_value