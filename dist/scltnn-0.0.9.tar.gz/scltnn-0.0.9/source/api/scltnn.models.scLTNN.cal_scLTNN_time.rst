scltnn.models.scLTNN.cal\_scLTNN\_time
======================================

.. currentmodule:: scltnn.models

.. automethod:: scLTNN.cal_scLTNN_time