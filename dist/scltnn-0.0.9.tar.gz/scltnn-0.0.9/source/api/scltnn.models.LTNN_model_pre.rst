scltnn.models.LTNN\_model\_pre
==============================

.. currentmodule:: scltnn.models

.. autofunction:: LTNN_model_pre