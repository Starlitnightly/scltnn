scltnn.datasets.Cancer\_CD8
===========================

.. currentmodule:: scltnn.datasets

.. autofunction:: Cancer_CD8