scltnn.models.scLTNN.cal\_dpt\_pseudotime
=========================================

.. currentmodule:: scltnn.models

.. automethod:: scLTNN.cal_dpt_pseudotime