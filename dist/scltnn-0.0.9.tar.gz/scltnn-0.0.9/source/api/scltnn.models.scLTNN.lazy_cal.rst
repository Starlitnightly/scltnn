scltnn.models.scLTNN.lazy\_cal
==============================

.. currentmodule:: scltnn.models

.. automethod:: scLTNN.lazy_cal