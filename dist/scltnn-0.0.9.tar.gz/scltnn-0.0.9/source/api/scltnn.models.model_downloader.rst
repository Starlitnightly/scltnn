scltnn.models.model\_downloader
===============================

.. currentmodule:: scltnn.models

.. autofunction:: model_downloader