scltnn.plot
===========

.. automodule:: scltnn.plot

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
      :nosignatures:
   
      get_publication_colors
      plot_high_correlation_heatmap
      plot_origin_tesmination
      set_publication_params
   
   

   
   
   

   
   
   



