scltnn.utils.cal\_paga
======================

.. currentmodule:: scltnn.utils

.. autofunction:: cal_paga