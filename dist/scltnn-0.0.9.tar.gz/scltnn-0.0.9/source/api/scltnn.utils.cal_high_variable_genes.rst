scltnn.utils.cal\_high\_variable\_genes
=======================================

.. currentmodule:: scltnn.utils

.. autofunction:: cal_high_variable_genes