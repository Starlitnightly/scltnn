scltnn.models.scLTNN.cal\_model\_time
=====================================

.. currentmodule:: scltnn.models

.. automethod:: scLTNN.cal_model_time