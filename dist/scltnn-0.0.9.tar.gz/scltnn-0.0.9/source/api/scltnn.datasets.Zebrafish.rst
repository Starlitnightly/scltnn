scltnn.datasets.Zebrafish
=========================

.. currentmodule:: scltnn.datasets

.. autofunction:: Zebrafish