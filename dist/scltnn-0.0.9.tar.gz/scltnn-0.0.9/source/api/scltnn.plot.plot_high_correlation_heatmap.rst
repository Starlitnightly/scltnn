scltnn.plot.plot\_high\_correlation\_heatmap
============================================

.. currentmodule:: scltnn.plot

.. autofunction:: plot_high_correlation_heatmap