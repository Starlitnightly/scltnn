scltnn.models.scLTNN.cal\_lsi
=============================

.. currentmodule:: scltnn.models

.. automethod:: scLTNN.cal_lsi