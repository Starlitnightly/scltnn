scltnn.models.scLTNN.distribute\_fun
====================================

.. currentmodule:: scltnn.models

.. automethod:: scLTNN.distribute_fun