scltnn.models.scLTNN.cal\_rps\_value
====================================

.. currentmodule:: scltnn.models

.. automethod:: scLTNN.cal_rps_value