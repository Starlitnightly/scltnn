scltnn.models.scLTNN.cal\_paga
==============================

.. currentmodule:: scltnn.models

.. automethod:: scLTNN.cal_paga