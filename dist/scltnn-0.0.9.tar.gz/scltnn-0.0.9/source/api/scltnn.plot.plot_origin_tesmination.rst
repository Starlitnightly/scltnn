scltnn.plot.plot\_origin\_tesmination
=====================================

.. currentmodule:: scltnn.plot

.. autofunction:: plot_origin_tesmination