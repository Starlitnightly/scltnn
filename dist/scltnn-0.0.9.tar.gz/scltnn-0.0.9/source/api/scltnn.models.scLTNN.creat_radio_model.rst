scltnn.models.scLTNN.creat\_radio\_model
========================================

.. currentmodule:: scltnn.models

.. automethod:: scLTNN.creat_radio_model