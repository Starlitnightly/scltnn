scltnn.utils.find\_related\_gene
================================

.. currentmodule:: scltnn.utils

.. autofunction:: find_related_gene