# Release notes

## v 1.0.0

First public release