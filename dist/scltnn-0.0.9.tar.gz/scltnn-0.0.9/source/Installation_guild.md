# Installation guild

## Main package

The `scltnn` package can be installed via pip using one of the following commands:

```
pip install scltnn
```

**Note** To avoid potential dependency conflicts, installing within a pip environment is recommended.

